# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.Games', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['flake8>=5.0.4,<6.0.0', 'prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.brain_calc:main',
                     'brain-even = brain_games.scripts.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main',
                     'brain-gcd = brain_games.scripts.brain_gcd:main',
                     'brain-prime = brain_games.scripts.brain_prime:main',
                     'brain-progression = '
                     'brain_games.scripts.brain_progression:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': '',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/mikel-x1/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/mikel-x1/python-project-49/actions)\n\n<a href="https://codeclimate.com/github/mikel-x1/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/9d7b964df4d6ce8cf811/maintainability" /></a>\n\nПроект "Игры разума". Содержит в себе следующие игры:\n\n\t1. brain_even - игра на проверку четности. Если число четное, нужно ответить yesб иначе - no\n\t2. brain_calc - игра позволяет проверить навыки вычисления (сумма, разность и произведение) двух чисел.\n\t3. brain_gcd - игра, в которой нужно найти наибольший общий делитель для двух чисел.\n\t4. brain_progression - игра, в которой необходимо определить пропущенный элемент арифметической прогрессии.\n\t5. brain_prime - игра, в которой нужно определить, является ли предложенное число простым. Если является - ответить yes, в противном случае - no.\nВсе игры проходят три раунда. Если в одном из раундов игрок ошибся - он проиграл, а игра заканчивается.\n\nУстановка: pip install --user git+github.com:mikel-x1/python-project-49.git\n\nДля запуска игры нужно набрать соответсвующую команду (brain-even и т.п.)\n\n\n\n<a href="https://asciinema.org/a/oucLHeFDrCoLpDck0hnVtqbzD" target="_blank"><img src="https://asciinema.org/a/oucLHeFDrCoLpDck0hnVtqbzD.svg" /></a>\n\n<a href="https://asciinema.org/a/eQHaPvFRFiYoVslrjYZB88f4D" target="_blank"><img src="https://asciinema.org/a/eQHaPvFRFiYoVslrjYZB88f4D.svg" /></a>\n\n<a href="https://asciinema.org/a/3dfgtSh5O41JuBTmMLcrmsImP" target="_blank"><img src="https://asciinema.org/a/3dfgtSh5O41JuBTmMLcrmsImP.svg" /></a>\n\n<a href="https://asciinema.org/a/z261kSdFBr1vnBNsMETWMjlUw" target="_blank"><img src="https://asciinema.org/a/z261kSdFBr1vnBNsMETWMjlUw.svg" /></a>\n\n<a href="https://asciinema.org/a/UCM9Qaz5pmMbJJ4ULPylad3kr" target="_blank"><img src="https://asciinema.org/a/UCM9Qaz5pmMbJJ4ULPylad3kr.svg" /></a>\n',
    'author': 'mikel-x1',
    'author_email': 'mikel-x1@yandex.ru',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8.1,<4.0.0',
}


setup(**setup_kwargs)
