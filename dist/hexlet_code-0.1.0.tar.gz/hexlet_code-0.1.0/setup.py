# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.games', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['flake8>=5.0.4,<6.0.0', 'prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.brain_calc:main',
                     'brain-even = brain_games.scripts.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main',
                     'brain-gcd = brain_games.scripts.brain_gcd:main',
                     'brain-prime = brain_games.scripts.brain_prime:main',
                     'brain-progression = '
                     'brain_games.scripts.brain_progression:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': '',
    'long_description': '# Brain Games\n\n[![Actions Status](https://github.com/mikel-x1/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/mikel-x1/python-project-49/actions)\n<a href="https://codeclimate.com/github/mikel-x1/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/9d7b964df4d6ce8cf811/maintainability" /></a>\n\n# Description\n\nThe games are Even Number, Calculator, Greatest Common Divisor, Progression, and Prime Number.\n\nOn startup, each app asks the user\'s name and then shows a task. If the user gives an incorrect answer, they loose. To win, user needs to give 3 correct answers in a row.\n\n\n# Dependencies\n\tpython = "^3.8.1"\n\tprompt = "^0.4.1"\n\n# Installation\n\nInstall make. Install Poetry.\n\nMake the root directory of the project your current directory. Use the following command to install Brain Games:\n\n\tmake package-install\n\n# Launching game\n\nAfter installation use the following commands to launch games\n\n\nEven Number:\n\n\tbrain-even\n\nCalculator:\n\n\tbrain-calc\n\nGreatest Common Divisor:\n\n\tbrain-gcd\n\nProgression:\n\n\tbrain-progression\n\nPrime Number:\n\n\tbrain-prime\n\nInstallation and gameplay screencast:\n<a href="https://asciinema.org/a/dYOfAJxbHDaqthnIyUeERpxkQ" target="_blank"><img src="https://asciinema.org/a/dYOfAJxbHDaqthnIyUeERpxkQ.svg" /></a>\n',
    'author': 'mikel-x1',
    'author_email': 'mikel-x1@yandex.ru',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8.1,<4.0.0',
}


setup(**setup_kwargs)
