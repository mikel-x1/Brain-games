### Hexlet tests and linter status:
[![Actions Status](https://github.com/mikel-x1/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/mikel-x1/python-project-49/actions)

https://asciinema.org/a/oucLHeFDrCoLpDck0hnVtqbzD

https://asciinema.org/a/eQHaPvFRFiYoVslrjYZB88f4D

https://asciinema.org/a/3dfgtSh5O41JuBTmMLcrmsImP

https://asciinema.org/a/z261kSdFBr1vnBNsMETWMjlUw

https://asciinema.org/a/GtsjHN5oHEk83CvFQ8yCRv847
