#!/usr/bin/env python3

from brain_games.even_game import game


def main():
    print('Welcome to the Brain Games!')
    game()

if __name__ == '__main__':
    main()
